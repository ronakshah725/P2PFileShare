package annotations;

public @interface unused {

}
