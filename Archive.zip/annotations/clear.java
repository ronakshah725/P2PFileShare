package annotations;
public @interface clear {

}
